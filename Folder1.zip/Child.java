public class Child extends Ticket{
   /**
	 * Returns the price of the purchased ticket
	 * @return the price of the purchased ticket.
	 */
  public double calculateTicketPrice() {
    double price;
    if (getRating() != "G" || getRating() != "PG")
      return Double.NaN;
    if (getTime() < getTimeShift())
      price = 5.75;
    else 
      price = 10.75;
    if (getFormat() == IMAX)
      price += 2.00;
    else if (getFormat() == TREE_D)
      price += 1.50;
    price = price * (1 + getTaxRate());
    return price;
  }
  /**
	 * Returns the Id number for a non-employee
	 * @return the Id number for a non-employee.
	 */
  public int getId() {
    return -1;
  }
}