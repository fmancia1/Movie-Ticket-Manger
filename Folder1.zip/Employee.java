public class Employee extends Ticket{
  /**
	 * Returns the price of the purchased ticket
	 * @return the price of the purchased ticket.
	 */
  public double calculateTicketPrice() {
    double price;
    if (getMovieCounter() <= 2)
      price = 0.0;
    else {
      Adult adult = new Adult(getMovie(), getRating(), getDay(), getTime(), getFormat());
      price = adult.calculateTicketPrice() / 2.0;
    }
    return price;
  }
}