public class MoviePass extends Ticket{
    /**
	 * Returns the price of the purchased ticket
   * @param id of the patron
	 * @return the price of the purchased ticket.
	 */
  public double calculateTicketPrice(LocalTime _time, Format _format, String _rating) {
    double price;
    boolean isAble = !isDateAttended(getDay()) && 
      !isMovieAttended(getMovie()) &&
      getFormat() != IMAX && format != THREE_D;
    if (isAble) {
      if (getMovieCounter() == 0)
        price = 9.99;
      else
        price = 0.0;
    }
    else {
      Adult adult = new Adult(getMovie(), getRating(), getDay(), getTime(), getFormat());
      price = adult.calculateTicketPrice();
    }
    return price;
  }
}