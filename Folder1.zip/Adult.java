public class Adult extends Ticket{
  /**
	 * Returns the price of the purchased ticket
	 * @return the price of the purchased ticket.
	 */
  public double calculateTicketPrice() {
    double price;
    if (getTime() < getTimeShift())
      price = 10.50;
    else 
      price = 13.50;
    if (getFormat() == IMAX)
      price += 3.00;
    else if (getFormat() == TREE_D)
      price += 2.50;
    price = price * (1 + getTaxRate());
    return price;
  }
  /**
	 * Returns the Id number for a non-employee
	 * @return the Id number for a non-employee.
	 */
  public int getId() {
    return -1;
  }
}